
// animat card ui //

var swiper = new Swiper(".mySwiper", {
  effect: "cards",
  grabCursor: true,
  initialSlide: 2,
  loop: true,
  rotate: true,
  mousewheel: {
    invert: true,
  },
});